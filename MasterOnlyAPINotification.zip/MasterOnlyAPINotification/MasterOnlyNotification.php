<?php
// =========================================================================================================
// DATABASE DEPENDENCIES
// =========================================================================================================
    require 'vendor/autoload.php';
    header('Access-Control-Allow-Origin: *');
    $dhost = "127.0.0.1";
    $dusername = "app";
    $dpassword = "sau03magen";
    $ddatabase = "MasterOnlyDB";

    $timestamp = date('Y-m-d H:i:s');

    function Q(&$con,$q)
    {
        try
        {
            $res = mysqli_query($con,$q);
        }
        catch(Exception $e)
        {
            $SQL_ERR=$e->getMessage();
            echo "QUERIUL $q a DAT: $SQL_ERR<br>\n";

            $EscapedQ=mysqli_real_escape_string($con,$q);
            $EscapedErr=mysqli_real_escape_string($con,$SQL_ERR);
            $PhpFile=mysqli_real_escape_string($con,$PhpFile);
            mysqli_query($con,
                "Insert into PyramidMonitor.LogPHPErrors (Q,ErrorMsg,PhpFile)
                VALUES
                ('$EscapedQ','$EscapedErr','$PhpFile')");
        }
        return $res;
    }
    
    	function str_after($subject, $search)
	{
	    if ($search == '') {
		return $subject;
	    }
	    $pos = strpos($subject, $search);
	    if ($pos === false) {
		return $subject;
	    }
	    return substr($subject, $pos + strlen($search));
	}

 while(true) {
    sleep(2);
    echo('Ok');
    
    $con = mysqli_connect($dhost, $dusername, $dpassword, $ddatabase) or die ("Cannot connect to the database");
    $notification = Q($con,"SELECT * FROM APINotification");

    if($notification->num_rows) {

        $notifcationConfig = Q($con,"SELECT Details FROM APINotificationConfig WHERE Type='LINK'");
        foreach($notifcationConfig as $index => $valuesArray){
            foreach($valuesArray as $column => $value) {
                $settings = $value;
            }
        }

        $userInitial = str_after($settings, "user=");
        $passwordInitial = str_after($settings, "password=");
        $sourceInitial = str_after($settings, "source=");
        $platformInitial = str_after($settings, "platformId=");
        $platformPatnerInitial = str_after($settings, "platormPartenerId=");

        $user = strtok($userInitial, '|');
        $password = strtok($passwordInitial, '|');
        $source = strtok($sourceInitial, '|');
        $platform =  strtok($platformInitial, '|');
        $platformPartner =  strtok($platformPatnerInitial, '|');

        $id = 0;
        foreach($notification as $index => $columnName) {
            $id += 1;
            $client[$id] = new GuzzleHttp\Client();

            if($index = 'Destination') {
                $numberLenght = strlen($columnName['Destination']);
                if($columnName['Destination'][0] == 0 && $columnName['Destination'][1] == 7 && $numberLenght == 10) {
                    $columnName['Destination'] = "+4" . $columnName['Destination'];
                } elseif($columnName['Destination'][0] == "4" && $numberLenght == 11) {
                    $columnName['Destination'] = "+" . $columnName['Destination'];
                } elseif($columnName['Destination'][0] == "7" && $numberLenght == 9) {
                    $columnName['Destination'] = "+40" . $columnName['Destination'];
                }
            }

            $checkNumberLenght = strlen($columnName['Destination']);

            if($checkNumberLenght == 12) {
                $res = $client[$id]->request('POST', 'https://n-eu.linkmobility.io/sms/send', [
                    'auth' => [$user, $password],
                    'json' => [
                        'source' => $source,
                        "destination"=> $columnName['Destination'],
                        "userData"=> $columnName['UserData'],
                        "platformId"=> $platform,
                        "platformPartnerId"=> $platformPartner,
                        "useDeliveryReport"=> false
                    ]
                ]);
                $ids = $columnName['id'];
                $notification = Q($con,"DELETE FROM APINotification WHERE id=$ids");
            }


        }
    }
 }
?>    

